(function(){
  'use strict';

  const api = globalThis.browser || globalThis.chrome;
  const CONFIG_KEY = 'feelwriteConfig';
  const CACHE_KEY = 'feelwriteUnlockCache';

  function storageGet(keys){
    if(globalThis.browser && browser.storage) return browser.storage.local.get(keys);
    return new Promise((resolve, reject)=>{
      chrome.storage.local.get(keys, result=>{
        const error = chrome.runtime.lastError;
        if(error) reject(new Error(error.message));
        else resolve(result || {});
      });
    });
  }

  function storageSet(values){
    if(globalThis.browser && browser.storage) return browser.storage.local.set(values);
    return new Promise((resolve, reject)=>{
      chrome.storage.local.set(values, ()=>{
        const error = chrome.runtime.lastError;
        if(error) reject(new Error(error.message));
        else resolve();
      });
    });
  }

  function normalizeConfig(raw){
    const source = raw && typeof raw === 'object' ? raw : {};
    const supabaseUrl = String(source.supabaseUrl || source.url || '').trim().replace(/\/$/, '');
    const anonKey = String(source.anonKey || '').trim();
    const syncCode = String(source.syncCode || '').trim();
    const trackerUrl = String(source.trackerUrl || '').trim();
    return {
      supabaseUrl,
      anonKey,
      syncCode,
      trackerUrl:/^(https?:\/\/|file:\/\/)/i.test(trackerUrl) ? trackerUrl : ''
    };
  }

  function isConfigValid(config){
    const value = normalizeConfig(config);
    return /^https:\/\/[a-zA-Z0-9.-]+\.supabase\.co$/.test(value.supabaseUrl)
      && value.anonKey.length > 20
      && value.syncCode.length >= 12;
  }

  function parseSetupCode(value){
    let parsed;
    try{
      parsed = JSON.parse(String(value || '').trim());
    } catch(error){
      throw new Error('Der Setup-Code ist kein gueltiges JSON.');
    }
    const config = normalizeConfig(parsed);
    if(!isConfigValid(config)) throw new Error('Der Setup-Code ist unvollstaendig.');
    return config;
  }

  function normalizeVideoId(value){
    const id = String(value || '').trim();
    return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : '';
  }

  function extractVideoId(value){
    const raw = String(value || '').trim();
    const direct = normalizeVideoId(raw);
    if(direct) return direct;
    let url;
    try{
      url = new URL(raw);
    } catch(error){
      return '';
    }
    const host = url.hostname.toLowerCase().replace(/^www\./, '');
    if(host === 'youtu.be') return normalizeVideoId(url.pathname.split('/').filter(Boolean)[0]);
    const queryId = normalizeVideoId(url.searchParams.get('v'));
    if(queryId) return queryId;
    const parts = url.pathname.split('/').filter(Boolean);
    if(['shorts','live','embed'].includes(parts[0])) return normalizeVideoId(parts[1]);
    return '';
  }

  function normalizeUnlocks(raw){
    const seen = new Set();
    return (Array.isArray(raw) ? raw : []).map(entry=>{
      const videoId = normalizeVideoId(entry && (entry.videoId || entry.video_id)) || extractVideoId(entry && entry.url);
      if(!videoId || seen.has(videoId)) return null;
      seen.add(videoId);
      return {
        videoId,
        title:String(entry.title || `YouTube Video ${videoId}`).slice(0, 100),
        purchasedAt:Number(entry.purchasedAt || entry.purchased_at) || 0
      };
    }).filter(Boolean);
  }

  async function fetchUnlocks(config){
    const normalized = normalizeConfig(config);
    if(!isConfigValid(normalized)) throw new Error('Extension ist nicht verbunden.');
    const response = await fetch(`${normalized.supabaseUrl}/rest/v1/rpc/load_youtube_unlocks`, {
      method:'POST',
      headers:{
        apikey:normalized.anonKey,
        Authorization:`Bearer ${normalized.anonKey}`,
        'Content-Type':'application/json'
      },
      body:JSON.stringify({ p_sync_code:normalized.syncCode })
    });
    if(!response.ok){
      let detail = '';
      try{ detail = await response.text(); } catch(error){}
      throw new Error(`Supabase antwortet mit ${response.status}${detail ? `: ${detail.slice(0, 180)}` : ''}`);
    }
    const payload = await response.json();
    const row = Array.isArray(payload) ? payload[0] : payload;
    const unlocks = normalizeUnlocks(row && row.unlocks);
    const cache = {
      unlocks,
      updatedAt:String(row && row.updated_at || ''),
      fetchedAt:Date.now()
    };
    await storageSet({ [CACHE_KEY]:cache });
    return cache;
  }

  globalThis.FeelWriteYouTubeSync = {
    api,
    CONFIG_KEY,
    CACHE_KEY,
    storageGet,
    storageSet,
    normalizeConfig,
    isConfigValid,
    parseSetupCode,
    normalizeVideoId,
    extractVideoId,
    normalizeUnlocks,
    fetchUnlocks
  };
})();
