(function(){
  'use strict';

  const sync = globalThis.FeelWriteYouTubeSync;
  const setupInput = document.getElementById('setupCode');
  const saveButton = document.getElementById('saveButton');
  const syncButton = document.getElementById('syncButton');
  const statusPill = document.getElementById('statusPill');
  const statusMessage = document.getElementById('statusMessage');
  const unlockCount = document.getElementById('unlockCount');
  const trackerButton = document.getElementById('trackerButton');
  let currentConfig = null;

  function setBusy(busy){
    saveButton.disabled = busy;
    syncButton.disabled = busy;
  }

  function setStatus(type, message, count){
    const ready = type === 'ready';
    statusPill.classList.toggle('ready', ready);
    statusPill.textContent = ready ? 'Verbunden' : (type === 'error' ? 'Fehler' : 'Nicht verbunden');
    statusMessage.textContent = message;
    if(Number.isFinite(count)) unlockCount.textContent = String(count);
    trackerButton.hidden = !(currentConfig && currentConfig.trackerUrl);
  }

  async function loadStatus(){
    const stored = await sync.storageGet([sync.CONFIG_KEY, sync.CACHE_KEY]);
    currentConfig = sync.normalizeConfig(stored[sync.CONFIG_KEY]);
    const cache = stored[sync.CACHE_KEY];
    if(!sync.isConfigValid(currentConfig)){
      setStatus('empty', 'Fuege einmalig den Setup-Code aus dem YouTube-Shop ein.', 0);
      return;
    }
    const count = sync.normalizeUnlocks(cache && cache.unlocks).length;
    setStatus('ready', cache && cache.fetchedAt ? `Zuletzt aktualisiert: ${new Date(cache.fetchedAt).toLocaleString('de-DE')}` : 'Verbindung gespeichert. Jetzt aktualisieren.', count);
  }

  async function refresh(){
    if(!sync.isConfigValid(currentConfig)){
      setStatus('empty', 'Noch keine gueltige Verbindung gespeichert.', 0);
      return;
    }
    setBusy(true);
    statusMessage.textContent = 'Freischaltungen werden geladen...';
    try{
      const cache = await sync.fetchUnlocks(currentConfig);
      setStatus('ready', `Aktuell: ${new Date(cache.fetchedAt).toLocaleString('de-DE')}`, cache.unlocks.length);
    } catch(error){
      setStatus('error', error && error.message ? error.message : 'Synchronisierung fehlgeschlagen.');
    } finally {
      setBusy(false);
    }
  }

  saveButton.addEventListener('click', async()=>{
    setBusy(true);
    try{
      currentConfig = sync.parseSetupCode(setupInput.value);
      await sync.storageSet({ [sync.CONFIG_KEY]:currentConfig });
      setupInput.value = '';
      await refresh();
    } catch(error){
      setStatus('error', error && error.message ? error.message : 'Setup-Code konnte nicht gespeichert werden.');
      setBusy(false);
    }
  });

  syncButton.addEventListener('click', refresh);
  trackerButton.addEventListener('click', ()=>{
    if(currentConfig && currentConfig.trackerUrl) window.open(currentConfig.trackerUrl, '_blank', 'noopener');
  });

  loadStatus().catch(error=>setStatus('error', error.message || 'Status konnte nicht geladen werden.'));
})();
