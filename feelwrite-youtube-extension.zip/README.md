# FeelWrite YouTube Gate

Die Extension erlaubt auf YouTube nur Videos, die im YouTube-Tab des FeelWrite Shops gekauft wurden.

## Einmalige Einrichtung

1. In Supabase den Inhalt von `supabase_youtube_unlocks_upgrade.sql` im SQL Editor ausfuehren.
2. Im Habit Tracker unter Einstellungen dieselben Supabase-Daten auf allen Geraeten eintragen.
3. `Auto Sync` und `Auto Load On Start` aktivieren.
4. Die Extension im jeweiligen Browser installieren.
5. Im Habit Tracker den Shop und dann den Tab `YouTube` oeffnen.
6. `Extension-Setup kopieren` auswaehlen.
7. Das Extension-Symbol oeffnen, den Code einfuegen und `Verbinden` auswaehlen.

## Chrome auf dem PC

1. `chrome://extensions` oeffnen.
2. Entwicklermodus aktivieren.
3. `Entpackte Erweiterung laden` auswaehlen.
4. Den Ordner `feelwrite-youtube-extension` auswaehlen.

## Orion auf dem iPad

1. Orion aus dem App Store installieren.
2. In Orion unter Einstellungen die Unterstuetzung fuer Chrome Extensions aktivieren.
3. Menue -> Extensions -> `+` oeffnen.
4. Die Datei `feelwrite-youtube-extension.zip` aus der Dateien-App auswaehlen.
5. Der Extension Zugriff auf YouTube erlauben.

Brave auf iPadOS unterstuetzt diese Extension nicht. YouTube muss dort in Orion verwendet werden.

## Verhalten

- Der Preis betraegt 10 Coins pro Video.
- Freischaltungen sind dauerhaft.
- Normale Videos, `youtu.be`-Links, Shorts, Livestreams und Embeds werden erkannt.
- Auf YouTube bleiben Suche, Kanaele, Kommentare und Navigation nutzbar.
- Nicht gekaufte Videos und Vorschau-Autoplay werden angehalten und ausgeblendet.
- Die Extension aktualisiert die Freischaltungen bei jedem Video und danach alle 15 Sekunden.
- Ohne Netzwerk bleiben bereits zwischengespeicherte Freischaltungen nutzbar.
