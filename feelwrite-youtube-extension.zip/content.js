(function(){
  'use strict';

  const sync = globalThis.FeelWriteYouTubeSync;
  if(!sync) return;

  const REFRESH_MS = 15000;
  let config = null;
  let unlockIds = new Set();
  let currentVideoId = '';
  let currentUrl = '';
  let mode = 'loading';
  let refreshPromise = null;
  let evaluationToken = 0;
  let overlay = null;
  let overlayTitle = null;
  let overlayText = null;
  let overlayId = null;
  let trackerButton = null;

  function setRootState(value){
    mode = value;
    const root = document.documentElement;
    if(root) root.setAttribute('data-feelwrite-youtube-state', value);
  }

  function getMediaElements(){
    return [...document.querySelectorAll('video, audio')];
  }

  function stopMedia(){
    getMediaElements().forEach(media=>{
      if(!media.dataset.feelwritePreviousMuted) media.dataset.feelwritePreviousMuted = media.muted ? '1' : '0';
      try{ media.pause(); } catch(error){}
      media.muted = true;
    });
  }

  function releaseMedia(){
    getMediaElements().forEach(media=>{
      if(media.dataset.feelwritePreviousMuted){
        media.muted = media.dataset.feelwritePreviousMuted === '1';
        delete media.dataset.feelwritePreviousMuted;
      }
    });
  }

  function createOverlay(){
    if(overlay || !document.body) return overlay;
    overlay = document.createElement('div');
    overlay.id = 'feelwrite-youtube-gate';
    overlay.setAttribute('data-visible', 'false');

    const card = document.createElement('div');
    card.className = 'feelwrite-youtube-gate-card';
    const mark = document.createElement('div');
    mark.className = 'feelwrite-youtube-gate-mark';
    mark.textContent = 'YT';
    overlayTitle = document.createElement('div');
    overlayTitle.className = 'feelwrite-youtube-gate-title';
    overlayText = document.createElement('div');
    overlayText.className = 'feelwrite-youtube-gate-text';
    overlayId = document.createElement('div');
    overlayId.className = 'feelwrite-youtube-gate-id';

    const actions = document.createElement('div');
    actions.className = 'feelwrite-youtube-gate-actions';
    const refreshButton = document.createElement('button');
    refreshButton.type = 'button';
    refreshButton.className = 'feelwrite-youtube-gate-button primary';
    refreshButton.textContent = 'Freischaltungen aktualisieren';
    refreshButton.addEventListener('click', ()=>evaluateCurrentPage(true));
    trackerButton = document.createElement('button');
    trackerButton.type = 'button';
    trackerButton.className = 'feelwrite-youtube-gate-button';
    trackerButton.textContent = 'Habit Tracker oeffnen';
    trackerButton.addEventListener('click', ()=>{
      if(config && config.trackerUrl) window.open(config.trackerUrl, '_blank', 'noopener');
    });
    actions.append(refreshButton, trackerButton);
    card.append(mark, overlayTitle, overlayText, overlayId, actions);
    overlay.append(card);
    document.body.append(overlay);
    return overlay;
  }

  function positionOverlay(){
    if(!overlay || overlay.getAttribute('data-visible') !== 'true') return;
    const target = document.querySelector('#movie_player, ytd-player, #player-container, video');
    if(!target) return;
    const rect = target.getBoundingClientRect();
    if(rect.width < 80 || rect.height < 60) return;
    overlay.style.left = `${Math.max(0, rect.left)}px`;
    overlay.style.top = `${Math.max(0, rect.top)}px`;
    overlay.style.width = `${Math.min(window.innerWidth - Math.max(0, rect.left), rect.width)}px`;
    overlay.style.height = `${Math.min(window.innerHeight - Math.max(0, rect.top), rect.height)}px`;
  }

  function hideOverlay(){
    if(overlay) overlay.setAttribute('data-visible', 'false');
  }

  function showOverlay(nextMode, videoId, errorMessage=''){
    if(!createOverlay()) return;
    const copy = {
      loading:['Freischaltung wird geprueft', 'Die aktuelle Liste wird mit FeelWrite synchronisiert.'],
      locked:['Video nicht freigeschaltet', 'Kaufe dieses Video zuerst im YouTube-Tab des FeelWrite Shops.'],
      config:['Extension noch nicht verbunden', 'Oeffne das Extension-Symbol und fuege den Setup-Code aus FeelWrite ein.'],
      error:['Synchronisierung fehlgeschlagen', errorMessage || 'Die Freischaltungen konnten nicht geladen werden.']
    }[nextMode] || ['Video gesperrt', 'Dieses Video kann gerade nicht abgespielt werden.'];
    overlayTitle.textContent = copy[0];
    overlayText.textContent = copy[1];
    overlayId.textContent = videoId ? `Video-ID: ${videoId}` : '';
    trackerButton.style.display = config && config.trackerUrl ? '' : 'none';
    overlay.setAttribute('data-visible', 'true');
    positionOverlay();
  }

  async function loadStoredState(){
    const stored = await sync.storageGet([sync.CONFIG_KEY, sync.CACHE_KEY]);
    config = sync.normalizeConfig(stored[sync.CONFIG_KEY]);
    const cachedUnlocks = sync.normalizeUnlocks(stored[sync.CACHE_KEY] && stored[sync.CACHE_KEY].unlocks);
    unlockIds = new Set(cachedUnlocks.map(entry=>entry.videoId));
    return stored[sync.CACHE_KEY] || null;
  }

  async function refreshUnlocks(force=false){
    if(refreshPromise) return refreshPromise;
    refreshPromise = (async()=>{
      const cache = await loadStoredState();
      if(!sync.isConfigValid(config)) return { status:'config' };
      const cacheAge = Date.now() - Number(cache && cache.fetchedAt || 0);
      if(!force && cache && cacheAge < REFRESH_MS) return { status:'ok', cached:true };
      try{
        const fresh = await sync.fetchUnlocks(config);
        unlockIds = new Set(fresh.unlocks.map(entry=>entry.videoId));
        return { status:'ok', cached:false };
      } catch(error){
        if(cache && Array.isArray(cache.unlocks)) return { status:'cached-error', error };
        return { status:'error', error };
      }
    })();
    try{
      return await refreshPromise;
    } finally {
      refreshPromise = null;
    }
  }

  async function evaluateCurrentPage(forceRefresh=false, background=false){
    const token = ++evaluationToken;
    const videoId = sync.extractVideoId(location.href);
    const wasAllowed = mode === 'allowed' && currentVideoId === videoId;
    currentVideoId = videoId;

    if(!videoId){
      setRootState('browse');
      hideOverlay();
      stopMedia();
      return;
    }

    if(!background){
      setRootState('loading');
      stopMedia();
      showOverlay('loading', videoId);
    }
    const result = await refreshUnlocks(forceRefresh);
    if(token !== evaluationToken || videoId !== sync.extractVideoId(location.href)) return;

    if(result.status === 'config'){
      if(background && wasAllowed) return;
      setRootState('config');
      stopMedia();
      showOverlay('config', videoId);
      return;
    }
    if(result.status === 'error'){
      if(background && wasAllowed) return;
      setRootState('error');
      stopMedia();
      showOverlay('error', videoId, result.error && result.error.message);
      return;
    }
    if(unlockIds.has(videoId)){
      setRootState('allowed');
      hideOverlay();
      releaseMedia();
      return;
    }
    // Freischaltungen sind dauerhaft. Ein laufendes erlaubtes Video wird daher
    // bei einem leeren oder veralteten Hintergrund-Ergebnis nicht unterbrochen.
    if(background && wasAllowed) return;
    setRootState('locked');
    stopMedia();
    showOverlay('locked', videoId);
  }

  function watchPage(){
    if(location.href !== currentUrl){
      currentUrl = location.href;
      evaluateCurrentPage(true);
      return;
    }
    if(mode !== 'allowed'){
      stopMedia();
      positionOverlay();
    }
  }

  setRootState('loading');
  document.addEventListener('play', event=>{
    if(mode !== 'allowed' && event.target && typeof event.target.pause === 'function'){
      event.target.pause();
      event.target.muted = true;
    }
  }, true);
  document.addEventListener('yt-navigate-start', ()=>{
    setRootState('loading');
    stopMedia();
  }, true);
  document.addEventListener('yt-navigate-finish', ()=>evaluateCurrentPage(true), true);
  window.addEventListener('popstate', ()=>evaluateCurrentPage(true));
  window.addEventListener('resize', positionOverlay);

  if(sync.api && sync.api.storage && sync.api.storage.onChanged){
    sync.api.storage.onChanged.addListener((changes, areaName)=>{
      if(areaName !== 'local') return;
      if(changes[sync.CONFIG_KEY]) evaluateCurrentPage(false);
      else if(changes[sync.CACHE_KEY]) evaluateCurrentPage(false, true);
    });
  }

  setInterval(watchPage, 500);
  setInterval(()=>{
    if(document.visibilityState === 'visible' && currentVideoId) evaluateCurrentPage(true, true);
  }, REFRESH_MS);
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', ()=>evaluateCurrentPage(true), { once:true });
  } else {
    evaluateCurrentPage(true);
  }
})();
